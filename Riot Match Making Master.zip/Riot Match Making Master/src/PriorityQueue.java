import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
public class PriorityQueue implements PriorityQueueADT {
	
	private ArrayList<Player> prioQueue;
	
	private int heapSize;
	
	public PriorityQueue() {
		prioQueue = new ArrayList<Player>();
		heapSize = 0;
	}
	private int parent(int index) {
		return (index-1)/2;
	}
	private int left(int index) {
		return 2*index+1;
	}
	private int right(int index) {
		return 2*index +2;
	}

	public void maxHeapify(int index, int positionNeeded) { 
		int l = left(index);
		int r = right(index);
		int largest = index;
		int position = positionNeeded;
		int l_key = 0, r_key = 0, largest_key, index_key;
		int n = heapSize -1;
		if (l <= n && r <= n) {
			l_key = prioQueue.get(l).getPositionKey(position);
			r_key = prioQueue.get(r).getPositionKey(position);
		}
	    index_key = prioQueue.get(index).getPositionKey(position);
		if ( (l <= n) && (l_key > index_key)) {
			largest = l;
		} 
		largest_key = prioQueue.get(largest).getPositionKey(position);
		if ( (r <= n) && (r_key > largest_key)) {
			largest = r;
		}
		if (largest != index){
			Collections.swap(prioQueue, index, largest);
			maxHeapify(largest, position);
		}
	}
	public void buildMaxHeap(int positionNeeded) {
		int position = positionNeeded;
		for(int i = ((heapSize)/2 -1) ; i >=0; i--) {
			maxHeapify(i, position);
		}
	}
	public void heapSort(int positionNeeded) { //just need to make sure passing 5 every time with prioQueue
		int position = positionNeeded; 
		buildMaxHeap(position);
		int n = prioQueue.size();
		for (int i = n-1; i >=1; i--) {
			Collections.swap(prioQueue, 0, i);
			heapSize --;
		    maxHeapify(0, position);
		}
		heapSize = prioQueue.size(); 
	}

	public Boolean insert(Player player) {
		prioQueue.add(player);
		int position = 5; 
		int index = prioQueue.size() -1;
		try {
	    	int key = player.getPositionKey(position);
	    	changeKey(key, index, position);
	    	heapSize++;
	    	return true;
	    } catch(SmallerKeyException e) {
	    	return false;
	    }
		
	}
	public Player checkMaximum(int type) throws HeapUnderflowException {
		if (prioQueue.size() < 1) {
			throw new HeapUnderflowException();
		}
		buildMaxHeap(type);
		return prioQueue.get(0);
	}

	
	public Player getMaximum(int type) throws HeapUnderflowException{
		if (prioQueue.size() < 1) {
			throw new HeapUnderflowException();
		}
		buildMaxHeap(type);
		int n = prioQueue.size() -1;
		Player max = prioQueue.get(0);
		Collections.swap(prioQueue, 0, n);
		prioQueue.remove(n);
		heapSize--;
		if (!prioQueue.isEmpty()){
			maxHeapify(0, type);
		}
		
		return max;
	}
	public void changeKey(int key, int index, int positionKey) throws SmallerKeyException {
		int currentKey = prioQueue.get(index).getPositionKey(positionKey);
		if(key < currentKey) {
			throw new SmallerKeyException(key);
		}
		prioQueue.get(index).setQueueKey(key);
		int parentKey = prioQueue.get(parent(index)).getPositionKey(5);
		while ((index > 0) && (parentKey < currentKey)) {
			Collections.swap(prioQueue, index, parent(index));
			index = parent(index);
			parentKey = prioQueue.get(parent(index)).getPositionKey(5);
		}
		
	}
	public Boolean delete(Player player) {
		Iterator i = prioQueue.iterator();
		while(i.hasNext()) {
			if(i.equals(player)) {
				i.remove();
				return true;
			}
		}
		return false;
	}
	public String toString(int type) {
		heapSort(type); 
		String s = "";
		for(int i = 0; i < prioQueue.size(); i++) {
			int queukey = prioQueue.get(i).getPositionKey(type);
			s += String.format("%d: %s: Queue Key: %d\n",i, prioQueue.get(i).toString(), queukey);
		}
		return s;
	}
	public Boolean isEmpty() {
		Boolean empty = true;
		if (prioQueue.size() > 1) {
			empty = false;
		}
		return empty;
	}

	public void eraseQueue() throws HeapUnderflowException {
		// TODO Auto-generated method stub
		
	}
	
}
