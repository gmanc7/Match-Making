import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
public class PlayerBaseWriter {
	/**need to distribute based on rank, mmr, and then randomly generate roles for each player
	// CreateDatabase takes an input size number and creates a txt document with that many players.
	 * Format will be [summonerID, MMR, fillpriority, position1, position 2]
	 * Main will parse through the text document and fill the hashTable with appropriate player objects.  
	*/
	
	private void CreateDatabase(int numPlayers) throws IOException {
		FileWriter writer = new FileWriter("PlayerBase.txt");
		
	}

	
	
}
