import java.util.ArrayList;
import java.util.Random;

public class MatchMaking {
	/**
	 * This class will take as input a hash table of players and the total number of players. 
	 * size of arrays is how many "buckets" we want for mmr range. Since we want games to be composed of players that
	 * are within 5 mmr of each other and the total mmr range is from 750-2200, the size of the arrays will be
	 * (2200-750)/5 = 290
	 */
	private PriorityQueue[] allElo;
	private MatchBuilder[] allBuilder;
	private HashTable dict;
	public MatchMaking(HashTable table) { 
		dict = table;
		allElo = new PriorityQueue[290];
		allBuilder = new MatchBuilder[290];
		for (int i = 0; i < allElo.length; i++) {
			allElo[i] = new PriorityQueue();
		}
	}
	public void setPrioQueues() {
		PlayerInfo p = new PlayerInfo();
		Player player = new Player();
		int name;
		String checkName;
		Random randomGenerator = new Random();
		int numPlayers = dict.size();

		for (int i = 0; i < numPlayers; i++) {
			name = randomGenerator.nextInt(numPlayers);
			checkName = getSummoner(name);
			p = dict.get(checkName);
			while (p == null) {
				name = randomGenerator.nextInt(numPlayers)+1;
				checkName = getSummoner(name);
				p = dict.get(checkName);
			}
			try {
				dict.remove(p.getKey());
			} catch (NoKeyException e) {
				System.out.println("Need to fix Hash table");
			} 
			player = new Player(p);
			int index = getArrayPositions(player.getMMR());
			if (index < 290) {
				allElo[index].insert(player);
			} else {
				System.out.println("index was too big");
			}
			
		}
	}
	public void setMB() {
		for (int i = 0; i< allElo.length; i++) {
			allBuilder[i] = new MatchBuilder(allElo[i]);
		}
	}
	public void sort() {
		for (int i = 0; i< allBuilder.length; i++) {
			allBuilder[i].initialBuild();
			try {
				allBuilder[i].mbPolymerase();
			} catch (HeapUnderflowException e) {
				System.out.println("PrioQueue was empty");
			}
		}
	}
	public ArrayList<Team> getRandomTeams(int num) {
		ArrayList<Team> teams = new ArrayList<Team>();
		Random randomGenerator = new Random();
		int elo, teamIndex;
		for (int i = 0; i < num; i++) {
			elo = randomGenerator.nextInt(allElo.length);
			int test = allBuilder[elo].getfilledSize();
			teamIndex = randomGenerator.nextInt(test);
			teams.add(allBuilder[elo].removeIndex(teamIndex));
		}
		return teams;
	}
	public String getSummoner(int s) {
		String summoner;
		summoner = new Integer(s).toString();                        // this creates a summoner name based on the Integer value. 
		for (int j = 0; j < 3; ++j) summoner += summoner;
		return summoner;
	}
	public int getArrayPositions(int MMR) {
		int index = 0;
		index = (MMR-750)/5;
		if (index > 289) {
			index = index%289;
		}
		return index;
	}
}
