import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;

public class Team {
	private ArrayList<Player> team;
	private String state;
	public Team() {
		team = new ArrayList<Player>();
		for (int i = 0; i<5 ; i++) {
			Player p = new Player();
			team.add(p);
		}
		state = "missing";
	}
	public Team(Player player1,Player player2,Player player3,Player player4,Player player5) {
		team = new ArrayList<Player>();
		team.set(0, player1);
		team.set(1, player2);
		team.set(2, player3);
		team.set(3, player4);
		team.set(4, player5);
	}
	public boolean isFull() {
		boolean full = true;
		for (int i = 0; i<5; i++) {
			if (team.get(i).getKey().equals("Empty")) {
				full = false;
			}
		}
		if (full) {
			state = "ready";
		}
		return full;
	}
	public boolean isEmpty() {
		boolean empty = false;
		for (int i = 0; i<5; i++) {
			if(team.get(i).getKey().equals("Empty")) {
				empty = true;
			} else {
				empty = false;
			}
		}
		return empty;
	}
	public ArrayList<Integer> missingPosition() {
		ArrayList<Integer> missing = new ArrayList<Integer>();
		for (int i = 0; i<5; i++) {
			if (team.get(i).getKey().equals("Empty")) {
				missing.add(1);
			} else {
				missing.add(0);
			}
		}
		return missing;
	}
	public void setPlayer(int index, Player player) {
		team.set(index, player);
		if (isFull()) {
			state = "ready";
		}
	}
	public Player getPlayer(int index) {
		Player player;
		player = team.get(index);
		return player;
	}
	public int avgMMR() {
		int avgMMR = 0; 
		if (isFull()) {
			for (int i = 0; i<5; i++) {
				avgMMR += team.get(i).getMMR();
			}
		}
		avgMMR = avgMMR/5;
		return avgMMR;
	}
	public String toString() { 
		String s = "";
		for(int i = 0; i < team.size(); i++) {
			s += team.get(i).toString();
		}
		return s;
	}
}
