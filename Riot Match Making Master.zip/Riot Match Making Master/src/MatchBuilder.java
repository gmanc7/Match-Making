
import java.util.*;
public class MatchBuilder implements CustomListADT
{
	private PriorityQueue eloPool;
	private TeamNode<Team> head, tail;
	private int size, fillCount, fullSize;
	private Stack<ArrayList<Integer>> playersNeeded;
	public MatchBuilder(PriorityQueue eloPool) {
		Team test = new Team();
		head = new TeamNode<Team>(test);
		tail = head;
		this.eloPool = eloPool;
		size = 0;
		fillCount = 0;
		fullSize = 0;
		playersNeeded = new Stack<ArrayList<Integer>>();
	}
	
	public Team removeFirst() throws EmptyCollectionException, ArrayUnderflowException {
		Team readyforMatch;
		if (!head.getElement().isFull())
			throw new EmptyCollectionException ("Tried to put not full team into game");
		else  {
			readyforMatch = head.getElement();
			head = head.getNext();
		} 
		return readyforMatch;
	}
	public Team removeIndex(int index) {
		Team readyforMatch = new Team();
		TeamNode<Team> current = head;
		if (index < this.getSize())
			try {
				return this.removeFirst();
			} catch (EmptyCollectionException e) {
			
			} catch (ArrayUnderflowException e) {
			
			}
		for (int i = 0; i < index; i++) {
			current = current.getNext();
			readyforMatch = current.getElement();
		}
		return readyforMatch;
	}
	private void insert() {
		Team test = new Team();
		TeamNode<Team> newNode = new TeamNode<Team>(test);
		newNode.setPrevious(tail);
		tail.setNext(newNode);
		tail = newNode;
	}
	public void initialBuild() {  //grabs 50 players according to queue key and build teams according to primary positions
		LinkedList<Player> initialPlayers = grabPlayers(2, 10);
		ListIterator i = initialPlayers.listIterator();
		TeamNode<Team> current = head;
		while(i.hasNext()) {
			if (current.getElement().isFull()) {
				this.insert();
				current = current.getNext();
			}else{
				Player p = (Player) i.next();
				if (p.getPositionOne() == 5) {  // if player is fill just put him anywhere
					for (int index = 0; index < 5 ; index++) {
						if (current.getElement().getPlayer(index).getKey().equals("Empty")){
							current.getElement().setPlayer(index, p);
							break;
						}
					}
				} else {
					Boolean b = current.getElement().getPlayer(p.getPositionOne()).getKey().equals("Empty");
					if (b){
						current.getElement().setPlayer(p.getPositionOne(), p);
					} else {
						this.insert();
						size++;
						current = current.getNext();
						current.getElement().setPlayer(p.getPositionOne(), p);
					}
				}
			} 
			
		}
	}
	public void mbPolymerase() throws HeapUnderflowException {
		TeamNode<Team> current = head;
		TeamNode<Team> check;
		while (current != tail) { // traverse linked list forwards counting how many players are needed of each position to fill all the teams perfectly
			if(current == null || current.getNext() == null) return;
			if(eloPool.isEmpty()) {
				return;
			}
			check = current.getNext();
			if(current.getElement().isFull()) {
				current = current.getNext();
			} else {
				if (playersNeeded.empty()) {  //base case
				ArrayList<Integer> missing = current.getElement().missingPosition();
				for (int i = 0; i < missing.size(); i ++) {
					if (missing.get(i) == 1) {
						if(eloPool.isEmpty()) {
							return;
						}
						Player p = eloPool.checkMaximum(i);
						if(p.getPositionOne() == i || p.getPositionOne() == 5) {
							current.getElement().setPlayer(i, eloPool.getMaximum(i));
						} else if (p.getPositionTwo() == i || p.getPositionTwo() == 5) {
							current.getElement().setPlayer(i, eloPool.getMaximum(i));
						} else { //no player in prio queue has primary/ secondary for the missing position. Need to fill
							Player fill = eloPool.getMaximum(6);
							current.getElement().setPlayer(i, fill);
							fillCount++;
						}
					}
				}
				if(current.getElement().isFull()) {
					fullSize++;
					current = current.getNext();
					check = current;
					
				}
				//need to grab missing players from next node and push onto stack so when current points to next it has the needed players for current. 
				playersNeeded.push(check.getElement().missingPosition());
				} else { //we have the missing players for current on the stack
					ArrayList<Integer> missing = playersNeeded.pop();
					for (int i = 0; i < missing.size(); i ++) {
						if (missing.get(i) == 1) {
							if(eloPool.isEmpty()) {
								return;
							}
							Player p = eloPool.checkMaximum(i);
							if(p.getPositionOne() == i || p.getPositionOne() == 5) {    //match player with primary
								current.getElement().setPlayer(i, eloPool.getMaximum(i));
							} else if (p.getPositionTwo() == i || p.getPositionTwo() == 5) { //match player with secondary
								current.getElement().setPlayer(i, eloPool.getMaximum(i));
							} else { //no player in prio queue has primary/ secondary for the missing position. Need to fill
								Player fill = eloPool.getMaximum(6);
								current.getElement().setPlayer(i, fill);
								fillCount++;
							}
						}
					}
					if(current.getElement().isFull()) {
						fullSize++;
						current = current.getNext();
						check = current;
					}
					playersNeeded.push(check.getElement().missingPosition());
				}
			
			}
		}
		if(eloPool.isEmpty()) {
			System.out.println("Empty");
			return;
		} else {
			this.initialBuild();
			this.mbPolymerase();
		}
	}
	public int getFillTotal() {
		return fillCount;
	}
	public int getSize() {
		return size;
	}
	public int getfilledSize() {
		return fullSize;
	}
	public LinkedList<Player> grabPlayers(int type, int amount){
		Random randomGenerator = new Random();
		LinkedList<Player> players = new LinkedList<Player>();
		for (int i = amount; i > 0; i --) {
			int random = randomGenerator.nextInt(4);
			try {
				players.add(eloPool.getMaximum(random));
			} catch (HeapUnderflowException e) {
			    }
		}
		 
		return players;
	}

}
